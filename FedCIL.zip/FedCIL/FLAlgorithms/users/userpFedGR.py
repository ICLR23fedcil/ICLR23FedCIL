import torch
import torch.nn.functional as F
import numpy as np
from FLAlgorithms.users.userbase import User
import copy


class UserpFedGR(User):
    def __init__(self,
                 args, 
                 id, 
                 model, 
                 generator,
                 train_data, 
                 test_data,
                 label_info,
                 g,
                 c,
                 use_adam=False,
                 my_model_name=None,
                 classifier=None,
                 unique_labels=None,
                ):
        super().__init__(args, id, model, train_data, test_data, use_adam=use_adam, my_model_name = my_model_name, unique_labels=unique_labels)
        
        self.gen_batch_size = args.gen_batch_size
        self.label_info=label_info
        self.args = args
        self.fine_tune_iters = 200
        
        # AC GAN part
        self.generator = g
        self.generator_server = generator
        self.last_generator = None
        
        # classifier
        self.classifier = c
    
    # ==================================== AC - GAN as clients ================================
    
    def train_GAN(
        self,
        importance_of_new_task = .5,
        batch_size = 32,
        iterations = 3000,
        current_task = None,
        Fedavg = False
    ):
        
        # init loss:
        c_loss_all = 0
        g_loss_all = 0
        
        # preparation:
        self.clean_up_counts()
        
        # variables
        current_task = self.current_task # in AC-GAN, it starts with 1
        
        # device
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

        # mode
#         self.generator.train()
#         self.classifier.critic.train()
#         server_classifier.critic.eval()
        
        # ----------------------
        #   Generator training
        # ----------------------
        print('training GAN...')
        
        if self.args.fedcl == 1:
            #total_epoch = int(self.args.local_epochs * (self.args.num_glob_iters/5))
            total_epoch = self.args.iter_GR
            print_time = 10
            iters_per_print = int(total_epoch/print_time)

            for iteration in range(total_epoch):
                if iteration%iters_per_print == 0:
                    print('progress: ' + str(iteration) + '/' + str(total_epoch))
                
                samples = self.get_next_train_batch(count_labels = True)
                x, y = samples['X'].to(device), samples['y'].to(device)

                # obtain replay samples:
                if self.last_generator is not None:
                    x_, y_ = self.last_generator.sample(self.gen_batch_size, self.classes_past_task) # last_generator cannot generate current ones
                    x_ = x_.to(device)
                    y_ = y_.to(device)
                else:
                    x_ = y_ = None
                
                x_g = y_g = None
                
                result = self.generator.train_a_batch(
                    x  = x, y = y, x_=x_, y_=y_,
                    importance_of_new_task=importance_of_new_task, classes_so_far = self.classes_so_far)
                
                c_loss_all += result['c_loss']
                g_loss_all += result['g_loss']
                
   
        print('training finished')
   

    def train_Critic(
        self,
        glob_iter_,
        server_classifier,
        glob_iter,
        personalized,
        verbose,
        regularization,
        importance_of_new_task = .5,
        batch_size = 32,
        iterations = 3000,
        current_task = None,
        Fedavg = False
    ):
        

        self.clean_up_counts()
        
        # variables
        current_task = self.current_task # in AC-GAN, it starts with 1
        
        # device
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

        # mode
#         self.generator.train()
#         self.classifier.critic.train()
#         server_classifier.critic.eval()
                
        # ----------------------
        #   Classifier training
        # ----------------------

        for iteration in range(50):
            samples = self.get_next_train_batch(count_labels = True)
            x, y = samples['X'].to(device), samples['y'].to(device)
            
            # obtain replay samples
            if self.last_generator is not None:
                x_, y_ = self.last_generator.sample(self.gen_batch_size, self.classes_past_task) # last_generator cannot generate current ones
                x_ = x_.to(device)
                y_ = y_.to(device)
            else:
                x_ = y_ = None
            
            # train classifier
            self.classifier.train_a_batch(x, y, x_, y_)   

    # utils        
    def exp_lr_scheduler(self, epoch, decay=0.98, init_lr=0.1, lr_decay_epoch=1):    
        """Decay learning rate by a factor of 0.95 every lr_decay_epoch epochs."""
        lr= max(1e-4, init_lr * (decay ** (epoch // lr_decay_epoch)))
        return lr

    def update_label_counts(self, labels, counts):
        for label, count in zip(labels, counts):
            self.label_counts[int(label)] += count

    def clean_up_counts(self):
        del self.label_counts
        self.label_counts = {label:0 for label in range(self.unique_labels)}

