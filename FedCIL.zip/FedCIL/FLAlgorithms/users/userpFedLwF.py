import torch
import torch.nn.functional as F
import numpy as np
from FLAlgorithms.users.userbase import User
import copy
import torch.optim as optim

class UserpFedLwF(User):
    def __init__(self,
                 args, id, model,
                 train_data, test_data,
                 use_adam=False, my_model_name = None
                ):
        super().__init__(args, id, model, train_data, test_data, use_adam=use_adam, my_model_name = my_model_name)
        
        # para
        self.T = 2
        self.optimizer=torch.optim.Adam(
            params=self.model.parameters(),
            lr=0.0001, betas=(0.9, 0.999),
            eps=1e-08, weight_decay=1e-2, amsgrad=False)
        
        self.if_last_copy = False
        
    def train(self, server_model, glob_iter, personalized=False, early_stop=100, regularization=True, verbose=False):
        self.model.train()
        
        # define LOSS (to be printed)
        SERVER_LOSS, COPY_LOSS, P_LOSS = 0, 0, 0
        # T for kd
        T = self.T 
        
        for epoch in range(self.local_epochs):
            self.model.train()
            for i in range(self.K):
                self.optimizer.zero_grad()
                
                # sample from real dataset (un-weighted)
                samples =self.get_next_train_batch(count_labels=True)
                X, y = samples['X'].cuda(), samples['y'].cuda()
                
                #=======================
                # 1. classification loss
                #=======================
                model_result=self.model(X, logit=True)
                user_output_logp = model_result['output']
                predictive_loss=self.loss(user_output_logp, y)

                #===================================
                # 2. KD loss : last server -> client   
                #===================================
                if self.current_task > 0:
                    # user output possibility
                    user_logit = model_result['logit']
                    user_logit_p = F.softmax(user_logit/T, dim=1)

                    # server output p:
                    server_logit = server_model(X, logit=True)['logit']
                    server_logit_p = F.softmax(server_logit/T, dim=1).clone().detach()
                    
                    # kd loss:
                    kd_loss_server = self.ensemble_loss(torch.log(user_logit_p), server_logit_p)
                
                else:
                    kd_loss_server = 0
                #================================
                # 3. KD loss : last copy -> client
                #================================                
                if self.if_last_copy:
                    copy_logit = self.last_copy(X, logit=True)['logit']
                    copy_logit_p = F.softmax(copy_logit/T, dim=1).clone().detach()
                    
                    # kd loss:
                    kd_loss_copy = self.ensemble_loss(torch.log(user_logit_p), copy_logit_p)               
                
                else:
                    kd_loss_copy = 0
                
                
                if self.current_task > 0 and self.if_last_copy == True:   
                    alpha = 0.3
                    beta = 0.3
                
                else:
                    alpha = 1
                    beta = 0
                    
                loss_all = alpha * predictive_loss + beta * kd_loss_copy + (1 - alpha - beta) * kd_loss_server
                loss_all.backward()
                self.optimizer.step()
                
                SERVER_LOSS += kd_loss_server
                COPY_LOSS += kd_loss_copy
        
        # clone params of self.model into self.local_model
        self.clone_model_paramenter(self.model.parameters(), self.local_model)
        if personalized:
            self.clone_model_paramenter(self.model.parameters(), self.personalized_model_bar)
            
#         if SERVER_LOSS == COPY_LOSS == 0:
#             pass 
#         else:
#             SERVER_LOSS=SERVER_LOSS.detach().cpu().numpy() / (self.local_epochs * self.K)
#             COPY_LOSS=COPY_LOSS.detach().cpu().numpy() / (self.local_epochs * self.K)

#         info='\nUser Server Loss={:.4f}'.format(SERVER_LOSS)
#         info+=', Copy Loss={:.4f}'.format(COPY_LOSS)
#         print(info)