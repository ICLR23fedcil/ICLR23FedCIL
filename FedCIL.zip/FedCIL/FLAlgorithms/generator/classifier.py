from FLAlgorithms.generator import ganC
from torch import nn
import torch

class classifier():
    def __init__(self, image_size, image_channel_size, c_channel_size, dataset=None):
    
        self.image_size = image_size
        self.image_channel_size = image_channel_size
        self.c_channel_size = c_channel_size
        self.optimizer = None
        self.critic = None

        # criterions 
        self.aux_criterion = nn.NLLLoss()

         # Builind backbone
        if dataset == 'MNIST':
            self.critic = ganC.Critic(
                image_size=self.image_size,
                image_channel_size=self.image_channel_size,
                channel_size=self.c_channel_size,
            )

        if dataset == 'CIFAR10':
            self.critic = ganC.Critic_CIFAR(
                image_size=self.image_size,
                image_channel_size=self.image_channel_size,
                channel_size=self.c_channel_size,
          )

        if dataset == 'EMNIST-L':
            self.critic = ganC.Critic(
                image_size=self.image_size,
                image_channel_size=self.image_channel_size,
                channel_size=self.c_channel_size,
                num_classes = 26
            )

        if dataset == 'EMNIST-B':
            self.critic = ganC.Critic(
                image_size=self.image_size,
                image_channel_size=self.image_channel_size,
                channel_size=self.c_channel_size,
                num_classes = 47
            )

    def loss(self, x, y):
        
        _, aux_output, _ = self.critic(x.detach())
        aux_label = y
        
        loss = self.aux_criterion(torch.log(aux_output), aux_label)
        
        return loss
    
    def train_a_batch(self,x, y, x_=None, y_=None):
        
        # real samples
        loss = self.loss(x, y)
        # generated samples
        if x_ is not None and y_ is not None:
            loss_g = self.loss(x_, y_)
            loss = loss + loss_g
        
        # bp
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return