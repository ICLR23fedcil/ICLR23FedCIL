from FLAlgorithms.users.userpFedLwF import UserpFedLwF
from FLAlgorithms.servers.serverbase import Server
from utils.model_utils import read_data, read_user_data, aggregate_user_data, create_generative_model, read_user_data_cl
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torchvision.utils import save_image
import os
import copy
import time
MIN_SAMPLES_PER_LABEL=1

class FedLwF(Server):
    def __init__(self, args, model, seed):
        super().__init__(args, model, seed)

        # Initialize data for all users
        self.data = read_data(args.dataset)
        data = self.data
        
        # data contains: clients, groups, train_data, test_data, proxy_data
        clients = data[0]
        total_users = len(clients)
        self.total_users = total_users
        self.total_test_samples = 0
        self.local = 'local' in self.algorithm.lower()
        self.use_adam = 'adam' in self.algorithm.lower()
        self.early_stop = 20  # stop using generated samples after 20 local epochs
        self.my_model_name = 'fedlwf'
        
        # loss 
        self.init_loss_fn()
        
        #=========================
        # init users with task = 0
        #=========================
        self.users = []
    
        for i in range(total_users):
            # prepare datasets
            id, train_data, test_data, label_info = read_user_data_cl(i, data, dataset=args.dataset, count_labels=True, task = 0)

            # count total samples (accumulative)
            self.total_train_samples+=len(train_data)
            self.total_test_samples += len(test_data)
            id, train, test=read_user_data_cl(i, data, dataset=args.dataset, task = 0)
            
            # initialize Users with data
            user=UserpFedLwF(
                args, id, model,
                train_data, test_data,
                use_adam=self.use_adam,
                my_model_name = self.my_model_name
            )
            self.users.append(user)
            
            # update classes so far & current labels
            user.classes_so_far.extend(label_info['labels'])
            user.current_labels.extend(label_info['labels'])           
            
            # Network initialization
            for u in self.users:
                self.gaussian_intiailize(u.model, std=.02)
            
        # =================
        # training devices:
        # =================
        device = torch.device('cuda:0')
    
        for u in self.users:
            u.model.to(device)
        
        self.model.cuda()
            
    def train(self, args):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        N_TASKS = 5
        
        for task in range(N_TASKS):
            
            #================
            # Update dataset
            #================
            if task == 0:
                # update labels info. for the first task
                available_labels = set()
                available_labels_current = set()
                for u in self.users:
                    available_labels = available_labels.union(set(u.classes_so_far))
                    available_labels_current = available_labels_current.union(set(u.current_labels))
                    
                for u in self.users:
                    u.available_labels = list(available_labels)
                    u.available_labels_current = list(available_labels_current)
            
            else:
                self.current_task = task
                
                # save last copy of each client model:
                for u in self.users:
                    u.last_copy = copy.deepcopy(u.model)
                    u.if_last_copy = True
                
                for i in range(self.total_users):
                    
                    # 1. update dataset 
                    id, train_data, test_data, label_info = read_user_data_cl(i, self.data, dataset=args.dataset, count_labels=True, task = task)
                    
                    assert (self.users[i].id == id)
                    self.users[i].next_task(train_data, test_data, label_info)
                    
                     # 2. update labels info.
                    available_labels = set()
                    available_labels_current = set()
                    for u in self.users:
                        available_labels = available_labels.union(set(u.classes_so_far))
                        available_labels_current = available_labels_current.union(set(u.current_labels))

                    for u in self.users:
                        u.available_labels = list(available_labels)
                        u.available_labels_current = list(available_labels_current)           
            
            
                        
            #===================
            # print info.
            #===================
            if True:
                for u in self.users:
                    print("classes so far: ", u.classes_so_far)
                    print("available labels for the Client: ", u.available_labels)
                    print("available labels (current) for the Client: ", u.available_labels_current)
            
            #================
            # Begin training 
            #================
            epoch_per_task = int(self.num_glob_iters / N_TASKS)
            
            for glob_iter_ in range( epoch_per_task ):
                glob_iter = glob_iter_ + epoch_per_task * task
                
                print("\n\n------------- Round number:",glob_iter," | Current task:",task,"-------------\n\n")

                # select users
                self.selected_users, self.user_idxs=self.select_users(glob_iter, self.num_users, return_idx=True)
                
                # User para <- server para
                self.send_parameters(mode=self.mode)
 
                self.evaluate_()
                self.evaluate_all_()
                
                chosen_verbose_user = np.random.randint(0, len(self.users))
                self.timestamp = time.time() # log user-training start time
                
                #===============
                # 1. User update
                #===============
                '''
                1. regularization from global model: kd with its/global labels 
                2. regularization from itself
                '''

                for user_id, user in zip(self.user_idxs, self.selected_users): # allow selected users to train
                    verbose = user_id == chosen_verbose_user
                    # perform regularization using generated samples after the first communication round
                    user.train(
                        self.model,
                        glob_iter,
                        personalized=self.personalized,
                        early_stop=self.early_stop,
                        verbose=verbose and glob_iter > 0,
                        regularization= glob_iter > 0 )

                curr_timestamp = time.time() # log  user-training end time
                train_time = (curr_timestamp - self.timestamp) / len(self.selected_users)
                self.metrics['user_train_time'].append(train_time)
                self.timestamp = time.time() # log server-agg start time
                
                
                 # ============== Evaluation =============
                print('Evaluation before aggregation:')
                self.evaluate_all_(personal = True)               
                
                #=================
                # 2. Server update
                #=================
                # update server model as the aggregation of the users
                self.aggregate_parameters()

        self.save_results(args)
        self.save_model()

    def gaussian_intiailize(self, model, std=.01):
        modules = [m for n, m in model.named_modules() if 'conv' in n or 'fc' in n]
        parameters = [p for m in modules for p in m.parameters()]

        for p in parameters:
            if p.dim() >= 2:
                nn.init.normal_(p, std=std)
            else:
                nn.init.constant_(p, 0)  