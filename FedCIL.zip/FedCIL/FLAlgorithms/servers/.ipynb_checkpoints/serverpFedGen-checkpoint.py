from FLAlgorithms.users.userpFedGen import UserpFedGen
from FLAlgorithms.servers.serverbase import Server
from utils.model_utils import read_data, read_user_data, aggregate_user_data, create_generative_model, read_user_data_cl
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torchvision.utils import save_image
import os
import copy
import time
MIN_SAMPLES_PER_LABEL=1

class FedGen(Server):
    def __init__(self, args, model, seed):
        super().__init__(args, model, seed)

        # Initialize data for all users
        self.data = read_data(args.dataset)
        data = self.data
        
        # data contains: clients, groups, train_data, test_data, proxy_data
        clients = data[0]
        total_users = len(clients)
        self.total_users = total_users
        self.total_test_samples = 0
        self.local = 'local' in self.algorithm.lower()
        self.use_adam = 'adam' in self.algorithm.lower()

        self.early_stop = 20  # stop using generated samples after 20 local epochs
        self.student_model = copy.deepcopy(self.model)
        self.generative_model = create_generative_model(args.dataset, args.algorithm, self.model_name, args.embedding)  # define one GAN model
        
        # decide whether to generate features or images:
        self.generative_model.latent_layer_idx = -1
        
        if not args.train:
            
            print('number of generator parameteres: [{}]'.format(self.generative_model.get_number_of_parameters()))
            print('number of model parameteres: [{}]'.format(self.model.get_number_of_parameters()))
            
        self.latent_layer_idx = self.generative_model.latent_layer_idx  # to decide whether generate represenations or raw images
        self.init_ensemble_configs()
        
        print("latent_layer_idx: {}".format(self.latent_layer_idx))
        print("label embedding {}".format(self.generative_model.embedding))
        print("ensemeble learning rate: {}".format(self.ensemble_lr))
        print("ensemeble alpha = {}, beta = {}, eta = {}".format(self.ensemble_alpha, self.ensemble_beta, self.ensemble_eta))
        print("generator alpha = {}, beta = {}".format(self.generative_alpha, self.generative_beta))
        
        self.init_loss_fn()
        
        # prepare data_loaders
        # seems that they are not used in this file:
        # self.available_labels: all labels all users about to learn
        #self.train_data_loader, self.train_iter, self.available_labels = aggregate_user_data(data, args.dataset, self.ensemble_batch_size)
        #self.available_labels = [0,1,2,3,4,5,6,7,8,9]
        
        # paras for optimizers
        self.generative_optimizer = torch.optim.Adam(
            params=self.generative_model.parameters(),
            lr=self.ensemble_lr, betas=(0.9, 0.999),
            eps=1e-08, weight_decay=self.weight_decay, amsgrad=False)
        self.generative_lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(
            optimizer=self.generative_optimizer, gamma=0.98)
        
        self.optimizer = torch.optim.Adam(
            params=self.model.parameters(),
            lr=self.ensemble_lr, betas=(0.9, 0.999),
            eps=1e-08, weight_decay=0, amsgrad=False)
        
        self.lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer=self.optimizer, gamma=0.98)
        
        #=========================
        # init users with task = 0
        #=========================
        self.users = []
        self.available_labels = []
        for i in range(total_users):
            id, train_data, test_data, label_info = read_user_data_cl(i, data, dataset=args.dataset, count_labels=True, task = 0)
            
            # count total samples (accumulative)
            self.total_train_samples+=len(train_data)
            self.total_test_samples += len(test_data)
            id, train, test=read_user_data_cl(i, data, dataset=args.dataset, task = 0)
            
            # initialize Users with data:
            # self.available_labels: generated classes per User
            user=UserpFedGen(
                args, id, model, self.generative_model,
                train_data, test_data,
                self.available_labels, self.latent_layer_idx, label_info,
                use_adam=self.use_adam)
            self.users.append(user)
            
            # update calsses so far:
            user.classes_so_far.extend(label_info['labels'])
            
        print("Number of Train/Test samples:", self.total_train_samples, self.total_test_samples)
        print("Data from {} users in total.".format(total_users))
        print("Finished creating FedAvg server.")

    def train(self, args):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        N_TASKS = 5
        
        for task in range(N_TASKS):
            '''
            replace dataset for each TASK
            '''
            if task == 0:
                # update available lebels
                available_labels = []
                for i in range(self.total_users):
                    id, train_data, test_data, label_info = read_user_data_cl(i, self.data, dataset=args.dataset, count_labels=True, task = task)
                    
                    # update dataset and available_labels
                    assert (self.users[i].id == id)
                    available_labels.extend(label_info['labels']) # all labels in all users
                
                # update availabe_labels:
                available_labels = set(available_labels)
                available_labels = list(available_labels)
                for i in range(self.total_users):
                    self.users[i].available_labels.clear()
                    self.users[i].available_labels += available_labels
                
            else:
                # update datasets of users:
                available_labels = []
                
                for i in range(self.total_users):
                    id, train_data, test_data, label_info = read_user_data_cl(i, self.data, dataset=args.dataset, count_labels=True, task = task)
                    
                    # update available_labels
                    assert (self.users[i].id == id)
                    self.users[i].next_task(train_data, test_data, label_info)
                        
                    available_labels.extend(label_info['labels']) # all labels in all users
                   
                # update availabe labels of each user: 
                available_labels = set(available_labels)
                available_labels = list(available_labels)
                for i in range(self.total_users):
                    self.users[i].available_labels.clear()
                    self.users[i].available_labels += available_labels

            #=======================================
            # print info.
            #=======================================
            if True:
                for u in self.users:
                    print("classes so far: ", u.classes_so_far)
                    print("available labels", u.available_labels)
            
            # train
            epoch_per_task = int(self.num_glob_iters / N_TASKS)
            for glob_iter_ in range( epoch_per_task ):
                glob_iter = glob_iter_ + epoch_per_task * task
                
                print("\n\n------------- Round number:",glob_iter," | Current task:",task,"-------------\n\n")

                # select users
                self.selected_users, self.user_idxs=self.select_users(glob_iter, self.num_users, return_idx=True)

                # if arg.algorithm contains "local". In most cases, it does not.
                # broadcast averaged prediction model to clients
                if not self.local:
                    self.send_parameters(mode=self.mode) 

                self.evaluate()
                self.evaluate_all()
                chosen_verbose_user = np.random.randint(0, len(self.users))
                self.timestamp = time.time() # log user-training start time

                #===============
                # 1. User update
                #===============
                '''
                1. regularization from global model: kd with its/global labels 
                2. regularization from itself
                '''

                for user_id, user in zip(self.user_idxs, self.selected_users): # allow selected users to train
                    verbose = user_id == chosen_verbose_user
                    # perform regularization using generated samples after the first communication round
                    user.train(
                        glob_iter,
                        personalized=self.personalized,
                        early_stop=self.early_stop,
                        verbose=verbose and glob_iter > 0,
                        regularization= glob_iter > 0 )

                curr_timestamp = time.time() # log  user-training end time
                train_time = (curr_timestamp - self.timestamp) / len(self.selected_users)
                self.metrics['user_train_time'].append(train_time)
                if self.personalized:
                    self.evaluate_personalized_model()

                self.timestamp = time.time() # log server-agg start time

                #=================
                # 2. Server update
                #=================

                # train a GEN
                self.train_generator(
                    self.batch_size,
                    epoches=self.ensemble_epochs // self.n_teacher_iters,
                    latent_layer_idx=self.latent_layer_idx,
                    verbose=True
                )

                #=============================
                # user -> server(one time)
                #=============================
                # parameters:
                self.aggregate_parameters()

                curr_timestamp=time.time()  # log  server-agg end time
                agg_time = curr_timestamp - self.timestamp
                self.metrics['server_agg_time'].append(agg_time)
                if glob_iter  > 0 and glob_iter % 20 == 0 and self.latent_layer_idx == 0:
                    self.visualize_images(self.generative_model, glob_iter, repeats=10)

        self.save_results(args)
        self.save_model()

        
    def train_generator(self, batch_size, epoches=1, latent_layer_idx=-1, verbose=False):
        """
        Learn a generator that find a consensus latent representation z, given a label 'y'.
        :param batch_size:
        :param epoches:
        :param latent_layer_idx: if set to -1 (-2), get latent representation of the last (or 2nd to last) layer.
        :param verbose: print loss information.
        :return: Do not return anything.
        """
 
        # label counting is not required in our setting
        self.label_weights, self.qualified_labels = self.get_label_weights()
       
        TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS, STUDENT_LOSS2 = 0, 0, 0, 0

        def update_generator_(n_iters, student_model, TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS):
            '''
            student_model: the global model/"D"
            '''
            self.generative_model.train()
            student_model.eval()
            for i in range(n_iters): # iters per epoch
                self.generative_optimizer.zero_grad()
                
                # self.qualified_labels: all classes seen so far
                y=np.random.choice(self.qualified_labels, batch_size)
                
                y_input=torch.LongTensor(y)
                
                ## feed to generator
                gen_result=self.generative_model(y_input, latent_layer_idx=latent_layer_idx, verbose=True)
                # get approximation of Z( latent) if latent set to True, X( raw image) otherwise
                gen_output, eps=gen_result['output'], gen_result['eps']
                
                ##### get losses #####
                diversity_loss=self.generative_model.diversity_loss(eps, gen_output)  # encourage different outputs

                ######### get teacher loss ############
                teacher_loss=0
                teacher_logit=0
                for user_idx, user in enumerate(self.selected_users):
                    user.model.eval()
                    
                    # [label][weight of label in user_id]
                    weight=self.label_weights[y][:, user_idx].reshape(-1, 1)
                    
                    expand_weight=np.tile(weight, (1, self.unique_labels))
                    
                    user_result_given_gen=user.model(gen_output, start_layer_idx=latent_layer_idx, logit=True)
                    user_output_logp_=F.log_softmax(user_result_given_gen['logit'], dim=1)
                    
                    # match y (conditioned label) and ensemble output
                    # mean of a batch (32 samples)
                    teacher_loss_=torch.mean( \
                        self.generative_model.crossentropy_loss(user_output_logp_, y_input) * \
                        torch.tensor(weight, dtype=torch.float32))
                    teacher_loss+=teacher_loss_
                    teacher_logit+=user_result_given_gen['logit'] * torch.tensor(expand_weight, dtype=torch.float32)

                loss=self.ensemble_alpha * teacher_loss + self.ensemble_eta * diversity_loss
                
                loss.backward()
                self.generative_optimizer.step()
                TEACHER_LOSS += self.ensemble_alpha * teacher_loss
                DIVERSITY_LOSS += self.ensemble_eta * diversity_loss
                
            return TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS
        
        #============
        # Train a Gen
        #============
        for i in range(epoches):
            TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS=update_generator_(
                self.n_teacher_iters, self.model, TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS)

        TEACHER_LOSS = TEACHER_LOSS.detach().numpy() / (self.n_teacher_iters * epoches)
        STUDENT_LOSS = STUDENT_LOSS / (self.n_teacher_iters * epoches)
        DIVERSITY_LOSS = DIVERSITY_LOSS.detach().numpy() / (self.n_teacher_iters * epoches)
        info="Generator: Teacher Loss= {:.4f}, Student Loss= {:.4f}, Diversity Loss = {:.4f}, ". \
            format(TEACHER_LOSS, STUDENT_LOSS, DIVERSITY_LOSS)
        if verbose:
            print(info)
        self.generative_lr_scheduler.step()
        

    def get_label_weights(self):
        '''
        statistics: label info. from all clients
        '''
        label_weights = []
        qualified_labels = []
        
        # self.unique_labels : 0-9, pre-defined in 'config' file 
        for label in range(self.unique_labels):
            weights = []
            for user in self.selected_users:
                weights.append(user.label_counts[label]) # w[user id]: counts of this label in User
            
            # weights: 
            if np.max(weights) > MIN_SAMPLES_PER_LABEL: # 1
                qualified_labels.append(label)
            # uniform
            label_weights.append( np.array(weights) / np.sum(weights) )
        
        print(label_weights)
        
        label_weights = np.array(label_weights).reshape((self.unique_labels, -1))
        
        for user in self.selected_users:
            for label_ in range(10):
                print('label: ', label_)
                print(user.label_counts[label_])

        exit()
        
        print(label_weights)
        print(qualified_labels)
        exit()
        
        return label_weights, qualified_labels

    def get_qualified_labels(self):
        return

    def visualize_images(self, generator, glob_iter, repeats=1):
        """
        Generate and visualize data for a generator.
        """
        os.system("mkdir -p images")
        path = f'images/{self.algorithm}-{self.dataset}-iter{glob_iter}.png'
        y=self.available_labels
        y = np.repeat(y, repeats=repeats, axis=0)
        y_input=torch.tensor(y)
        generator.eval()
        images=generator(y_input, latent=False)['output'] # 0,1,..,K, 0,1,...,K
        images=images.view(repeats, -1, *images.shape[1:])
        images=images.view(-1, *images.shape[2:])
        save_image(images.detach(), path, nrow=repeats, normalize=True)
        print("Image saved to {}".format(path))
