# Better Generative Replay for Continual Federated Learning

### Usage

```
sh run-ous.sh # run generative replay based models

sh fedavg.sh # run FedAvg

sh fedlwf.sh # run FedLwF-2T
```

